/**
 * Package that contains standard implementations for
 * {@link com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder}
 * and
 * {@link com.fasterxml.jackson.databind.jsontype.TypeIdResolver}.
 */
package com.fasterxml.jackson.databind.jsontype.impl;
