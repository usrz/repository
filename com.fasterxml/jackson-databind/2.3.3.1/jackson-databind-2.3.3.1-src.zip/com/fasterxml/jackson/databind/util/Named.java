package com.fasterxml.jackson.databind.util;

/**
 * Simple tag interface mostly to allow sorting by name.
 */
public interface Named {
    public String getName();
}
